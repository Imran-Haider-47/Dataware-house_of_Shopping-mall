create table company.Products(
ProductID int Primary key not null,
Product_Name varchar(50),
Product_Price int);

insert into products
values(1,'Shampoo',500);
insert into products
values(2,'Face Wash',300);
